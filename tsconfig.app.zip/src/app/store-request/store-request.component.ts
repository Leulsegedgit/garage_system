import { Component, OnInit } from '@angular/core';
export interface store {
  no: number;
  request: string;
  service: string;
  requester: string;
  approver: string;
  date: string;
}

const ELEMENT_DATA: store[] = [
  {no: 1, request: 'r1234', service: 'ser123', requester: 'Yohannes',approver: 'Bishaw',date: '12-02-2014'},
  {no: 2, request: 'r1235', service: 'ser124', requester: 'Zelalem',approver: 'Hailu',date: '16-11-2014'},
  {no: 3, request: 'r1236', service: 'ser125', requester: 'Getnet',approver: 'Demle',date: '27-02-2014'},
  {no: 4, request: 'r1237', service: 'ser126', requester: 'Leulseged',approver: 'Wondimu',date: '12-02-2014'},
  {no: 5, request: 'r1238', service: 'ser127', requester: 'Mehariw',approver: 'Melak',date: '06-5-2014'}  
];
@Component({
  selector: 'app-store-request',
  templateUrl: './store-request.component.html',
  styleUrls: ['./store-request.component.css']
})
export class StoreRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  displayedColumns: string[] = ['no', 'request', 'service', 'requester','approver','date'];
  dataSource = ELEMENT_DATA;
}
