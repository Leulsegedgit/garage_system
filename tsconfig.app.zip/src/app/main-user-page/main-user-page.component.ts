import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-user-page',
  templateUrl: './main-user-page.component.html'
})
export class MainUserPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
