export class register {
    constructor(
    public id: string,
    public first_name: string,
    public last_name: string,
    public password: string,
    public confirm_password: string,
    public email: string,
    public check_box: boolean,
    public title: string
    ){}

}