import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-registration',
  templateUrl: './vehicle-registration.component.html',
  styleUrls: ['./vehicle-registration.component.css']
})
export class VehicleRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
