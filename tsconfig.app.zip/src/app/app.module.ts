import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule,routingComponents } from './app-routing.module';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UsersService } from './services/users.service';
import { MainAdminPageComponent } from './main-admin-page/main-admin-page.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RegisterService } from './services/register.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import {MatMenuModule} from '@angular/material/menu';
import {MatInputModule} from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox'; 
import {MatButtonModule} from '@angular/material/button'; 
import {MatSelectModule} from '@angular/material/select'; 
import {MatTableModule} from '@angular/material/table'; 

import {MatDatepickerModule} from '@angular/material/datepicker'; 
import {MatNativeDateModule} from '@angular/material/core';

import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ReceptionComponent } from './reception/reception.component';
import { VehicleRegistrationComponent } from './vehicle-registration/vehicle-registration.component';
import { StoreRequestComponent } from './store-request/store-request.component';
import { DashboardhomeComponent } from './dashboardhome/dashboardhome.component'


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    routingComponents,
    PageNotFoundComponent,
    MainAdminPageComponent,
    AdminDashboardComponent,
    ReceptionComponent,
    VehicleRegistrationComponent,
    StoreRequestComponent,
    DashboardhomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatToolbarModule,
    MatMenuModule,
    NgxChartsModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatTableModule
    
  ],
  providers: [UsersService,RegisterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
